<?php $__env->startSection('titulo', 'consultartaules'); ?>

<?php $__env->startSection('contenido'); ?>
<div class="container py-4">

    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2 class="h4 mb-0">Coches y extras</h2>
        <span class="text-muted"><?php echo e(count($relaciones)); ?> registros</span>
    </div>

    <?php if(session('ok')): ?>
        <div class="alert alert-success"><?php echo e(session('ok')); ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="ps-3">Matrícula</th>
                        <th>Marca</th>
                        <th>Modelo</th>
                        <th>Extra</th>
                        <th class="text-end pe-3">Precio</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $relaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="ps-3"><?php echo e($r->matricula); ?></td>
                            <td><?php echo e($r->marca); ?></td>
                            <td><?php echo e($r->modelo); ?></td>
                            <td><?php echo e($r->extra); ?></td>
                            <td class="text-end pe-3"><?php echo e(number_format($r->precio, 2, ',', '.')); ?> €</td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted py-4">
                                No hay relaciones para mostrar.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Trabajos_laragon\practica2_2MarcosGundin\resources\views/consultartaules.blade.php ENDPATH**/ ?>