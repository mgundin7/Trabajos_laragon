<?php $__env->startSection('titulo', 'insertarextras'); ?>

<?php $__env->startSection('contenido'); ?>
<div class="container py-4">

    <h2 class="h4 mb-3">Asignar extra a un coche</h2>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger"><?php echo e($errors->first()); ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('ce.insertar')); ?>">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label for="matricula" class="form-label">Coche</label>
                    <select name="matricula" id="matricula" class="form-select">
                        <?php $__currentLoopData = $coches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($c->matricula); ?>">
                                <?php echo e($c->matricula); ?> - <?php echo e($c->marca); ?> <?php echo e($c->modelo); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="id_extra" class="form-label">Extra</label>
                    <select name="id_extra" id="id_extra" class="form-select">
                        <?php $__currentLoopData = $extras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($e->id_extra); ?>"><?php echo e($e->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <button type="submit" class="btn btn-dark">Guardar</button>
            </form>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Trabajos_laragon\practica2_2MarcosGundin\resources\views/insertarextras.blade.php ENDPATH**/ ?>