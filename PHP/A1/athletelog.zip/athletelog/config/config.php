<?php 
    declare(strict_types=1);

    const pageTitle = "Athelte Log";
    const APP_OWNER = "Marcos Gundin Navarro";

    const APP_MENU = [
        '/index.php' => 'Inicio',
        '/registro.php' => 'Registro',
        '/Login.php' => 'Login',
        '/training.php' => 'Nuevo entrenamiento',
        '/history.php' => 'Historial',
        '/preferences.php' => 'Preferencias',
    ];
?>