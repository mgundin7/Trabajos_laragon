<?php 
    declare(strict_types=1);

    const pageTitle = "Athelte Log";
    const APP_OWNER = "Marcos Gundin Navarro";

    const APP_MENU = [
        'index.php' => 'Inicio',
        'register.php' => 'Registro',
        'login.php' => 'Login',
        'training.php' => 'Nuevo entrenamiento',
        'history.php' => 'Historial',
        'preferences.php' => 'Preferencias',
    ];
    
    const NOMBRE_MIN = 3;
    const NOMBRE_MAX = 50;
    const USUARIO_MIN = 4;
    const USUARIO_MAX = 15;
    const CONTRASENA_MIN = 8;
    const EDAD_MIN = 16;
    const EDAD_MAX = 60;
?>