<?php 
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

function renderHeader(string $title): void
{
?>
<html>
<head>
    <title><?= e(pageTitle) ?></title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<?php
}
?>
