<?php

declare(strict_types=1);

$pagina_actual = basename($_SERVER['PHP_SELF']);

function esActiva($pagina, $actual) {
    return $pagina === $actual ? ' class="activo"' : '';
}
?>