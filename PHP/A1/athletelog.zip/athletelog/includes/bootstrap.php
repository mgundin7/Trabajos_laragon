<?php
    declare(strict_types=1);

    include 'config/config.php';
    include 'includes/header.php';
    include 'includes/helpers.php';
    include 'includes/components.php';
?>