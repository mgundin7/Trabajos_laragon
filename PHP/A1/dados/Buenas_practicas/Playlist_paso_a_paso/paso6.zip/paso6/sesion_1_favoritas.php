<?php
declare(strict_types=1);

// EJEMPLO SESIÓN 1: Canciones favoritas
//
// Los datos se guardan en $_SESSION['favoritas'] (en el SERVIDOR).
// Se pierden al cerrar el navegador o al vaciar la lista.

require_once __DIR__ . '/src/bootstrap.php';

// Iniciar la sesión (antes de cualquier salida HTML)
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$songs = require __DIR__ . '/data/songs.php';

// Inicializar la lista de favoritas si no existe
if (!isset($_SESSION['favoritas']) || !is_array($_SESSION['favoritas'])) {
    $_SESSION['favoritas'] = [];
}

// Procesar acciones (solo por POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // El índice de la canción se valida: debe ser un entero que exista en $songs
    $indice = filter_var($_POST['indice'] ?? null, FILTER_VALIDATE_INT);
    $indiceValido = $indice !== false && isset($songs[$indice]);

    if (isset($_POST['agregar']) && $indiceValido) {
        if (!in_array($indice, $_SESSION['favoritas'], true)) {
            $_SESSION['favoritas'][] = $indice;
        }
    } elseif (isset($_POST['quitar']) && $indiceValido) {
        $_SESSION['favoritas'] = array_values(
            array_diff($_SESSION['favoritas'], [$indice])
        );
    } elseif (isset($_POST['vaciar'])) {
        $_SESSION['favoritas'] = [];
    }

    header('Location: ' . $_SERVER['PHP_SELF']);    // Evitar reenvío del formulario
    exit();
}

$favoritas = $_SESSION['favoritas'];

renderHeader('Sesión 1 - Favoritas');
?>

<h1>Sesión 1: Mis canciones favoritas</h1>

<p>Tienes <strong><?= count($favoritas) ?></strong> canción(es) en favoritas.</p>

<hr>

<h3>Todas las canciones</h3>
<ul>
    <?php foreach ($songs as $i => $song): ?>
        <li>
            <?= e($song['title']) ?> - <?= e($song['artist']) ?> (<?= e($song['minutes']) ?> min)
            <?php if (in_array($i, $favoritas, true)): ?>
                ⭐ Ya en favoritas
            <?php else: ?>
                <form method="POST" action="" style="display:inline">
                    <input type="hidden" name="indice" value="<?= e($i) ?>">
                    <button type="submit" name="agregar" value="1">➕ Añadir</button>
                </form>
            <?php endif; ?>
        </li>
    <?php endforeach; ?>
</ul>

<hr>

<h3>Mis favoritas</h3>
<?php if ($favoritas === []): ?>
    <p>Aún no has añadido ninguna canción.</p>
<?php else: ?>
    <ul>
        <?php foreach ($favoritas as $i): ?>
            <li>
                ⭐ <?= e($songs[$i]['title']) ?> - <?= e($songs[$i]['artist']) ?>
                <form method="POST" action="" style="display:inline">
                    <input type="hidden" name="indice" value="<?= e($i) ?>">
                    <button type="submit" name="quitar" value="1">❌ Quitar</button>
                </form>
            </li>
        <?php endforeach; ?>
    </ul>
    <form method="POST" action="">
        <button type="submit" name="vaciar" value="1">🗑️ Vaciar favoritas</button>
    </form>
<?php endif; ?>

<hr>

<h3>Información de la sesión</h3>
<table border="1" cellpadding="10" cellspacing="0">
    <tr>
        <th>Dato</th>
        <th>Valor</th>
    </tr>
    <tr>
        <td>ID de sesión</td>
        <td><code><?= e(session_id()) ?></code></td>
    </tr>
    <tr>
        <td>Favoritas guardadas</td>
        <td><?= count($favoritas) ?></td>
    </tr>
    <tr>
        <td>Contenido de $_SESSION['favoritas']</td>
        <td><code><?= e(json_encode($favoritas)) ?></code></td>
    </tr>
</table>

<p><small>Nota: la lista vive en el servidor y se pierde al cerrar el navegador.</small></p>

<?php renderFooter(); ?>
