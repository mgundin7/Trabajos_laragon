<?php
declare(strict_types=1);

// EJEMPLO SESIÓN 2: Login simulado
//
// Si las credenciales son correctas se guarda $_SESSION['usuario'] y
// la página pasa a mostrar la zona privada. Logout = destruir la sesión.
//
// Usuario de prueba -> usuario: admin | contraseña: 1234
// (Solo para practicar: en una web real los usuarios van en base de datos
//  y las contraseñas con password_hash() / password_verify()).

require_once __DIR__ . '/src/bootstrap.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

const USUARIO_DEMO = 'admin';
const PASSWORD_DEMO = '1234';

$error = '';

// 1. Cerrar sesión
if (isset($_POST['logout'])) {
    $_SESSION = [];     // Vaciar variables de sesión
    session_destroy();  // Destruir la sesión en el servidor
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit();
}

// 2. Intentar iniciar sesión
if (isset($_POST['login'])) {
    $usuarioRaw = $_POST['usuario'] ?? '';
    $passwordRaw = $_POST['password'] ?? '';
    $usuario = is_string($usuarioRaw) ? trim($usuarioRaw) : '';
    $password = is_string($passwordRaw) ? $passwordRaw : '';

    // hash_equals compara en tiempo constante (evita ataques de temporización)
    if (hash_equals(USUARIO_DEMO, $usuario) && hash_equals(PASSWORD_DEMO, $password)) {
        session_regenerate_id(true);    // Nuevo ID tras el login (evita fijación de sesión)
        $_SESSION['usuario'] = $usuario;
        $_SESSION['inicio_sesion'] = date('Y-m-d H:i:s');
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit();
    }
    $error = 'Usuario o contraseña incorrectos.';
}

// 3. ¿Hay un usuario identificado?
$logueado = isset($_SESSION['usuario']);

renderHeader('Sesión 2 - Login');
?>

<h1>Sesión 2: Login con sesiones</h1>

<?php if ($logueado): ?>
    <h2>Zona privada 🔒</h2>
    <p>Hola, <strong><?= e($_SESSION['usuario']) ?></strong>. Has iniciado sesión correctamente.</p>
    <p>Sesión iniciada el: <?= e($_SESSION['inicio_sesion']) ?></p>

    <form method="POST" action="">
        <button type="submit" name="logout" value="1">🚪 Cerrar sesión</button>
    </form>
<?php else: ?>
    <h2>Inicia sesión</h2>
    <p>Prueba con usuario <code>admin</code> y contraseña <code>1234</code>.</p>

    <?php if ($error !== ''): ?>
        <p role="alert"><?= e($error) ?></p>
    <?php endif; ?>

    <form method="POST" action="">
        <p>
            <label for="usuario">Usuario:</label><br>
            <input type="text" id="usuario" name="usuario" maxlength="30" required>
        </p>
        <p>
            <label for="password">Contraseña:</label><br>
            <input type="password" id="password" name="password" maxlength="60" required>
        </p>
        <button type="submit" name="login" value="1">🔑 Entrar</button>
    </form>
<?php endif; ?>

<hr>

<h3>Información de la sesión</h3>
<table border="1" cellpadding="10" cellspacing="0">
    <tr>
        <th>Dato</th>
        <th>Valor</th>
    </tr>
    <tr>
        <td>Usuario identificado</td>
        <td><?= $logueado ? '✅ Sí' : '❌ No' ?></td>
    </tr>
    <tr>
        <td>ID de sesión</td>
        <td><code><?= e(session_id()) ?></code></td>
    </tr>
    <tr>
        <td>Usuario en $_SESSION</td>
        <td><?= $logueado ? e($_SESSION['usuario']) : 'N/A' ?></td>
    </tr>
</table>

<p><small>Nota: la sesión se cierra al pulsar "Cerrar sesión", al cerrar el navegador o por inactividad.</small></p>

<?php renderFooter(); ?>
