

<?php $__env->startSection('titulo', 'Modificar'); ?>

<?php $__env->startSection('contenido'); ?>
<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-12 col-md-10 col-lg-8">

      <div class="card shadow-sm border-0">
        <div class="card-header bg-white d-flex justify-content-between align-items-center py-3">
          <h4 class="mb-0">Modificar coche</h4>
          <span class="badge bg-primary rounded-pill"><?php echo e(count($dades)); ?></span>
        </div>

        <?php if(count($dades) == 0): ?>
          <div class="card-body text-center py-5">
            <div class="fs-1">🚗</div>
            <p class="text-muted mb-0 mt-2">No hay coches para modificar.</p>
          </div>
        <?php else: ?>
          <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
              <thead class="table-light">
                <tr>
                  <th class="ps-4">Matrícula</th>
                  <th>Marca</th>
                  <th>Modelo</th>
                  <th>Año</th>
                  <th class="text-end pe-4">Acción</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $dades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="ps-4 fw-semibold"><?php echo e($i->matricula); ?></td>
                    <td><?php echo e($i->marca); ?></td>
                    <td><?php echo e($i->modelo); ?></td>
                    <td><?php echo e($i->año); ?></td>
                    <td class="text-end pe-4">
                      <a href="/modificar/<?php echo e($i->matricula); ?>" class="btn btn-sm btn-outline-primary">Editar</a>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\mgu2574\scoop\persist\laragon\www\practica2_2MarcosGundin\resources\views/modificar.blade.php ENDPATH**/ ?>