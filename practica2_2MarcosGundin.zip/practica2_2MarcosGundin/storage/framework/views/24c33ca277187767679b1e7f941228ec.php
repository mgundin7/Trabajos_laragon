

<?php $__env->startSection('titulo', 'consultartaules'); ?>

<?php $__env->startSection('contenido'); ?>
<h2>Coches y extras (N:M)</h2>

<?php if(session('ok')): ?>
    <p style="color:green"><?php echo e(session('ok')); ?></p>
<?php endif; ?>

<table border="1">
    <tr>
        <th>Matrícula</th>
        <th>Marca</th>
        <th>Modelo</th>
        <th>Extra</th>
        <th>Precio</th>
    </tr>
    <?php $__currentLoopData = $relaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($r->matricula); ?></td>
            <td><?php echo e($r->marca); ?></td>
            <td><?php echo e($r->modelo); ?></td>
            <td><?php echo e($r->extra); ?></td>
            <td><?php echo e($r->precio); ?> €</td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\mgu2574\scoop\persist\laragon\www\practica2_2MarcosGundin\resources\views/consultartaules.blade.php ENDPATH**/ ?>