

<?php $__env->startSection('titulo', 'Buscarresultado'); ?>

<?php $__env->startSection('contenido'); ?>
<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-12 col-md-10 col-lg-6">

      <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
          <?php echo e(session('success')); ?>

          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
        </div>
      <?php endif; ?>

      <div class="card shadow-sm border-0">
        <div class="card-header bg-white d-flex justify-content-between align-items-center py-3">
          <h4 class="mb-0">Resultado de la búsqueda</h4>
          <?php if(count($dades) > 0): ?>
            <span class="badge bg-primary rounded-pill"><?php echo e(count($dades)); ?></span>
          <?php endif; ?>
        </div>

        <div class="card-body p-0">
          <?php if(count($dades) == 0): ?>
            <div class="text-center py-5">
              <div class="fs-1">🚫</div>
              <h5 class="mt-2">Sin resultados</h5>
              <p class="text-muted mb-0">No se ha encontrado ningún coche con esa matrícula.</p>
            </div>
          <?php else: ?>
            <div class="table-responsive">
              <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                  <tr>
                    <th class="ps-4">Matrícula</th>
                    <th>Marca</th>
                    <th>Modelo</th>
                    <th>Año</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $dades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td class="ps-4 fw-semibold"><?php echo e($i->matricula); ?></td>
                      <td><?php echo e($i->marca); ?></td>
                      <td><?php echo e($i->modelo); ?></td>
                      <td><?php echo e($i->año); ?></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          <?php endif; ?>
        </div>

        <div class="card-footer bg-white text-center py-3">
          <a href="<?php echo e(url()->previous()); ?>" class="btn btn-outline-primary">← Nueva búsqueda</a>
        </div>
      </div>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\mgu2574\scoop\persist\laragon\www\Practica-2.1\resources\views/buscarresultado.blade.php ENDPATH**/ ?>