

<?php $__env->startSection('titulo', 'Consultar'); ?>

<?php $__env->startSection('contenido'); ?>
<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-12 col-md-10 col-lg-6">

      <div class="card shadow-sm border-0">
        <div class="card-header bg-white d-flex justify-content-between align-items-center py-3">
          <h4 class="mb-0">Coches disponibles</h4>
          <span class="badge bg-primary rounded-pill"><?php echo e(count($dades)); ?></span>
        </div>

        <?php if(count($dades) == 0): ?>
          <div class="card-body text-center py-5">
            <div class="fs-1">🚗</div>
            <p class="text-muted mb-0 mt-2">No hay coches registrados.</p>
          </div>
        <?php else: ?>
          <div class="list-group list-group-flush">
            <?php $__currentLoopData = $dades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <a href="/consultar/<?php echo e($i->matricula); ?>"
                 class="list-group-item list-group-item-action d-flex justify-content-between align-items-center py-3 px-4">
                <span>
                  <span class="fw-semibold"><?php echo e($i->marca); ?></span>
                  <small class="text-muted ms-2"><?php echo e($i->matricula); ?></small>
                </span>
                <span class="text-muted">›</span>
              </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        <?php endif; ?>
      </div>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\mgu2574\scoop\persist\laragon\www\practica2_2MarcosGundin\resources\views/consultar.blade.php ENDPATH**/ ?>