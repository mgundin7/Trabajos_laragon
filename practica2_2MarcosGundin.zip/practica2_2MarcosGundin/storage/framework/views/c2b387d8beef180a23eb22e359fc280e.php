

<?php $__env->startSection('titulo', 'Insertar coche'); ?>

<?php $__env->startSection('contenido'); ?>

<div class="container mt-5"> <div class="row justify-content-center">
    <div class="col-md-6">

        <div class="card shadow">

            <div class="card-header bg-dark text-white">
                <h3 class="mb-0">Insertar coche</h3>
            </div>

            <div class="card-body">

                <form action="<?php echo e(route('dades-insertar')); ?>" method="POST">

                    <?php echo csrf_field(); ?>

                    
                    <?php if(session('messagematriculaerror')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('messagematriculaerror')); ?>

                        </div>
                    <?php endif; ?>

                    
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    
                    <?php $__errorArgs = ['matricula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    
                    <?php $__errorArgs = ['marca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    
                    <?php $__errorArgs = ['modelo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <!-- Matrícula -->
                    <div class="mb-3">
                        <label for="matricula" class="form-label">
                            Matrícula
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            id="matricula"
                            name="matricula"
                            value="<?php echo e(old('matricula')); ?>"
                            placeholder="Ej. 1234ABC"
                            maxlength="7"
                            required>
                    </div>

                    <!-- Marca -->
                    <div class="mb-3">
                        <label for="marca" class="form-label">
                            Marca
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            id="marca"
                            name="marca"
                            value="<?php echo e(old('marca')); ?>"
                            placeholder="Ej. BMW"
                            required>
                    </div>

                    <!-- Modelo -->
                    <div class="mb-3">
                        <label for="modelo" class="form-label">
                            Modelo
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            id="modelo"
                            name="modelo"
                            value="<?php echo e(old('modelo')); ?>"
                            placeholder="Ej. Serie 3"
                            required>
                    </div>
                    <div class="mb-3">
                        <label for="año" class="form-label fw-semibold">
                            Año
                        </label>

                        <input 
                        type="number"
                        class="form-control"
                        name="año"
                        id="año"
                        value="<?php echo e(old('año')); ?>"
                        placeholder="Ej: 2020"
                        required>

                    <div class="d-grid">
                        <button type="submit" class="btn btn-dark mt-4">
                            Insertar coche
                        </button>
                    </div>

                </form>

            </div>

        </div>

    </div>

</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\mgu2574\scoop\persist\laragon\www\practica2_2MarcosGundin\resources\views/insertar.blade.php ENDPATH**/ ?>