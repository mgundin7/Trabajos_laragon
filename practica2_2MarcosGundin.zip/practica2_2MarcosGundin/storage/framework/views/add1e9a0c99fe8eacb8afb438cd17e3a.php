

<?php $__env->startSection('titulo', 'Nosotros'); ?>

<?php $__env->startSection('contenido'); ?>

<div class="container mt-5">

    <h1>Sobre nosotros</h1>

    <p>
        Somos AutoCars, un pequeño concesionario de coches.
    </p>

    <p>
        Vendemos coches nuevos y de segunda mano.
        Nuestro objetivo es ayudar a nuestros clientes
        a encontrar el coche que necesitan.
    </p>

    <img
        src="https://images.unsplash.com/photo-1560179707-f14e90ef3623?auto=format&fit=crop&w=900&q=80"
        class="img-fluid rounded"
        width="700"
        alt="Concesionario">

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\mgu2574\scoop\persist\laragon\www\practica2_2MarcosGundin\resources\views/nosaltres.blade.php ENDPATH**/ ?>