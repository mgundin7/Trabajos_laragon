

<?php $__env->startSection('titulo', 'insertarextras'); ?>

<?php $__env->startSection('contenido'); ?>
<h2>Asignar extra a un coche</h2>

<?php if($errors->any()): ?>
    <p style="color:red"><?php echo e($errors->first()); ?></p>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('ce.insertar')); ?>">
    <?php echo csrf_field(); ?>

    <label>Coche:</label>
    <select name="matricula">
        <?php $__currentLoopData = $coches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($c->matricula); ?>"><?php echo e($c->matricula); ?> - <?php echo e($c->marca); ?> <?php echo e($c->modelo); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <label>Extra:</label>
    <select name="id_extra">
        <?php $__currentLoopData = $extras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($e->id_extra); ?>"><?php echo e($e->nombre); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <button type="submit">Guardar</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\mgu2574\scoop\persist\laragon\www\practica2_2MarcosGundin\resources\views/insertarextras.blade.php ENDPATH**/ ?>