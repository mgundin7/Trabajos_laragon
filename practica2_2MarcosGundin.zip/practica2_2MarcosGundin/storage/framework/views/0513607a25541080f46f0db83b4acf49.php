

<?php $__env->startSection('titulo', 'Buscar'); ?>

<?php $__env->startSection('contenido'); ?>
<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-12 col-sm-10 col-md-6 col-lg-4">

      <div class="card shadow-sm border-0">
        <div class="card-body p-4">

          <div class="text-center mb-4">
            <div class="fs-1">🔍</div>
            <h3 class="card-title mb-1">Buscar coche</h3>
            <p class="text-muted mb-0">Introduce la matrícula del vehículo</p>
          </div>

          <form name="fbuscar" action="<?php echo e(route('dades-buscar')); ?>" method="POST" novalidate>
            <?php echo csrf_field(); ?>

            <div class="mb-3">
              <label for="matricula" class="form-label fw-semibold">Matrícula</label>
              <input type="text"
                     class="form-control form-control-lg <?php $__errorArgs = ['matricula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     name="matricula"
                     id="matricula"
                     value="<?php echo e(old('matricula')); ?>"
                     placeholder="Ej: 1234ABC"
                     autofocus>
              <?php $__errorArgs = ['matricula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button type="submit" class="btn btn-primary btn-lg w-100">Buscar</button>
          </form>

        </div>
      </div>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\mgu2574\scoop\persist\laragon\www\practica2_2MarcosGundin\resources\views/buscar.blade.php ENDPATH**/ ?>